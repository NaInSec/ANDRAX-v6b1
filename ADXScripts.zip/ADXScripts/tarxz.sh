tar -xvJf /sdcard/Download/andraxcorev6001.tar.xz -C /sdcard/Download/
# OR
# ./modtar -p --same-owner -xJf /sdcard/Download/andraxcorev6001.tar.xz -C /path/to/OUTPUTFOLDER


