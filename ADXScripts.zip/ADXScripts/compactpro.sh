./ccrypt -d -K "DickINOffensiveSecurityASS" /sdcard/Download/andraxcorev6001.tar.xz.cpt

sleep 01

# ./modtar -p --same-owner -xJf /sdcard/Download/andraxcorev6001.tar.xz -C ${CHROOT_DIR}/tmpsystem
# OR
# su -c busybox tar -xvJf /sdcard/Download/andraxcorev6001.tar.xz -C /data/data/com.thecrackertechnology.andrax/ANDRAX/
